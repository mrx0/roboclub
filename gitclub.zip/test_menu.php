<?php

//
//
	
	$DateForMove_week = date('j:n:Y', mktime (0, 0, 0, $m, $d+7, $y));
	$DateForMove_month = date('j:n:Y', mktime (0, 0, 0, $m, $d+7, $y));

	
	
?>