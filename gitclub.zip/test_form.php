<?php

	//require_once 'header.php';
	
	//был еще тест календарика
	//echo '<input id="calendar" name="date" value="01.11.2015" type="text"/>';
	
	var_dump ($_POST);
	var_dump ($_GET);
	
	//require_once 'footer.php';
	
?>